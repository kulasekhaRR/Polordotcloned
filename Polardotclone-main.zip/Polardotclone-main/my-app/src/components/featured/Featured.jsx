
import React from 'react'
import './featured.scss'
const Featured = () => {
  return (
    <div className="container">

    </div>
  )
}

export default Featured

